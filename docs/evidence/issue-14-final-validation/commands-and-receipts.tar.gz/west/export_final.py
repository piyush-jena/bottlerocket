"""Export both regions with the operator-approved GPU coverage limitation explicit."""
import datetime,hashlib,json,shutil,tarfile
from pathlib import Path
WEST=Path(__file__).resolve().parent
EAST=WEST.with_name('issue-14-systemd-guard-runtime')
MEMBER=WEST.parents[2]
DEST=MEMBER/'docs/evidence/issue-14-final-validation'
DEST.mkdir(parents=True,exist_ok=True)
rows=[]
for base,names in [(EAST,['aws-mantle-1-x86_64','aws-mantle-1-aarch64','aws-mantle-1-fips-x86_64']),(WEST,['aws-mantle-1-nvidia-x86_64','aws-mantle-1-nvidia-fips-x86_64'])]:
 for name in names:
  case=base/'cases'/name;result=json.loads((case/'result.json').read_text());assert result['status']==('passed' if base==EAST else 'not_run_missing_gpu'),name
  job=result['case']['job'];image=json.loads((base/'images'/job/'verification.json').read_text());inputs=json.loads((base/'images'/job/'inputs.json').read_text())
  invocations=[]
  for p in case.rglob('invocation.json'):
   d=json.loads(p.read_text());assert d['Status']=='Success' and d['ResponseCode']==0
   invocations.append({'command_id':d['CommandId'],'status':d['Status'],'response_code':d['ResponseCode'],'path':str(p.relative_to(base))})
  row={'case':name,'region':image['region'],'image':image,'artifacts':inputs['images'],'uefi_sha256':inputs['uefi_sha256'],'runtime':result,'ssm_commands':invocations}
  if (case/'followup/result.json').exists():row['followup']=json.loads((case/'followup/result.json').read_text())
  if base==WEST:
   row['static_inspection']=json.loads((base/'images'/job/'static-inspection.json').read_text());assert row['static_inspection']['status']=='passed';assert not invocations
  rows.append(row)
  dest=DEST/'cases'/name;dest.mkdir(parents=True,exist_ok=True)
  for n in ['result.json','policy-before.json','policy-after.json','native-smoke.stdout','boot-console.txt','boot-console-command.json']:
   if (case/n).exists():shutil.copy2(case/n,dest/n)
cleanups={r:json.loads((b/'cleanup/result.json').read_text()) for r,b in [('us-east-2',EAST),('us-west-2',WEST)]}
assert all(c['status']=='passed' for c in cleanups.values())
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'completed_with_operator_approved_gpu_coverage_limit','operator_instruction':json.loads((WEST/'operator-update.json').read_text()),'release':json.loads((WEST/'release-config.json').read_text()),'cases':rows,'cleanup':cleanups,'gpu_smoke':'Not run: capacity unavailable in both regions. NVIDIA flavors reached driver initialization on ordinary instances, then failed without GPU hardware, preventing configured.target and SSM. Their runtime policy/native/GPU smoke checks did not run. Both built images passed static blacklist and unit-absence checks. The operator authorized proceeding without GPU capacity.','registry_cleanup':'pending conductor'}
(WEST/'final-validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
for label,base in [('east',EAST),('west',WEST)]:
 for p in base.rglob('*'):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(base)
  if 'tools' in rel.parts or '__pycache__' in rel.parts:continue
  if p.suffix in {'.img','.lz4','.pyc','.tar','.gz','.pem'}:continue
  if p.name.startswith('lock-update-debug.'):continue
  assert p.stat().st_size<50000000,p
  files[label+'/'+str(rel)]=p
manifest={name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size} for name,p in sorted(files.items())}
with tarfile.open(DEST/'commands-and-receipts.tar.gz','w:gz') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
(DEST/'bundle-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for base,names in [(WEST,['final-validation-summary.json','operator-update.json','regional-artifact-equivalence.json','run_case.py','inspect_artifacts.py','fallback-observation-stop.json']),(EAST,['configuration-restored.json','release-config.json','tool-verification.json','registry-result.json','image-pins.json','workflow-source.json'])]:
 for name in names:shutil.copy2(base/name,DEST/name)
for region,c in cleanups.items():(DEST/('cleanup-'+region+'.json')).write_text(json.dumps(c,indent=2)+'\n')
receipt={'files':len(files),'archive_sha256':hashlib.sha256((DEST/'commands-and-receipts.tar.gz').read_bytes()).hexdigest()}
(DEST/'bundle-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)

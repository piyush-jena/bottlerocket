"""Reconcile refused launches before selecting another zone or CPU fallback."""
import json,subprocess,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
OUT=BASE/'capacity-recovery';OUT.mkdir(exist_ok=True)
network=json.loads((BASE/'network.json').read_text())
for name in ['aws-mantle-1-nvidia-x86_64','aws-mantle-1-nvidia-fips-x86_64']:
 p=BASE/'cases'/name
 if not p.exists():continue
 assert not (p/'identity.json').exists(),'Existing instance must not be relaunched'
 assert 'InsufficientInstanceCapacity' in (p/'launch.stderr').read_text()
 token=json.loads((p/'launch-input.json').read_text())['ClientToken']
 a=['aws','ec2','describe-instances','--filters','Name=client-token,Values='+token,'--region',network['region'],'--output','json']
 r=subprocess.run(a,capture_output=True,text=True,timeout=60)
 label=name+'-'+network['zone']
 (OUT/(label+'-reconcile.json')).write_text(json.dumps({'argv':a,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr},indent=2)+'\n')
 assert r.returncode==0 and not [i for res in json.loads(r.stdout)['Reservations'] for i in res['Instances']]
 p.rename(OUT/label)
if sys.argv[1]=='fallback':network['non_gpu_fallback']=True
else:
 chosen=next(s for s in network['candidate_subnets'] if s['zone']==sys.argv[1]);network.update(chosen)
(BASE/'network.json').write_text(json.dumps(network,indent=2)+'\n')
print(network['zone'],'CPU fallback' if network.get('non_gpu_fallback') else network['gpu_instance_type'],flush=True)

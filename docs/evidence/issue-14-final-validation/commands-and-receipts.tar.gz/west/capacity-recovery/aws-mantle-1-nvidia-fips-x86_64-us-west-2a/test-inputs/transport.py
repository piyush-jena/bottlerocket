"""Record SSM transport and complete command output for the supplied smoke recipe."""
import base64
import gzip
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import uuid

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[5]
HELPER = ROOT / "skills/cloud/ssm-executor/scripts/control-container-command.sh"
OUT = Path(os.environ["R10_COMMAND_LOG"])
OUT.mkdir(parents=True, exist_ok=True)
INSTANCE = os.environ["R10_INSTANCE"]
REGION = "us-west-2"

def ssm(label, command, timeout=180):
    directory = OUT / (label + "-" + uuid.uuid4().hex[:12])
    directory.mkdir()
    (directory / "command.txt").write_text(command + "\n")
    with (directory / "stdout.log").open("w") as stdout, (directory / "stderr.log").open("w") as stderr:
        response = subprocess.run([str(HELPER), INSTANCE, REGION, command],
            stdout=stdout, stderr=stderr, timeout=timeout+30,
            env=os.environ | {"SSM_TIMEOUT_SECONDS": str(timeout)})
    ids = re.findall(r"SSM command ID: ([\w-]+)", (directory / "stderr.log").read_text())
    assert len(ids) == 1, "Unknown send outcome; reconcile " + str(directory)
    result = subprocess.run(["aws", "ssm", "get-command-invocation", "--instance-id", INSTANCE,
        "--command-id", ids[0], "--region", REGION, "--output", "json"],
        capture_output=True, text=True, timeout=30)
    (directory / "invocation.json").write_text(result.stdout)
    assert result.returncode == 0, result.stderr
    invocation = json.loads(result.stdout)
    assert response.returncode == 0 and invocation["Status"] == "Success" and invocation["ResponseCode"] == 0, directory
    return invocation["StandardOutputContent"]

def admin(code):
    payload = base64.b64encode(gzip.compress(code.encode())).decode()
    stub = "import base64,gzip;exec(gzip.decompress(base64.b64decode(" + repr(payload) + ")))"
    return "apiclient exec admin python3 -c " + shlex.quote(stub)

def host(label, argv, timeout=180):
    name = uuid.uuid4().hex
    remote = "/.bottlerocket/rootfs/local/symphony-14-runtime/" + name
    code = f"""import gzip,json,pathlib,subprocess,time
p=pathlib.Path({remote!r});p.parent.mkdir(parents=True,exist_ok=True)
with p.with_suffix('.out').open('wb') as stdout,p.with_suffix('.err').open('wb') as stderr:
 r=subprocess.run({['sheltie', *argv]!r},stdout=stdout,stderr=stderr,timeout={max(1,timeout-30)})
files={{}}
for kind in ['out','err']:
 raw=p.with_suffix('.'+kind).read_bytes(); packed=gzip.compress(raw)
 target=p.with_suffix('.'+kind+'.gz');target.write_bytes(packed);files[kind]={{'path':str(target),'size':len(packed),'raw_size':len(raw)}}
print(json.dumps({{'returncode':r.returncode,'files':files}}))
"""
    receipt = json.loads(ssm(label, admin(code), timeout))
    directory = OUT / ("host-" + name)
    directory.mkdir()
    (directory / "result.json").write_text(json.dumps({"argv": argv, **receipt}, indent=2) + "\n")
    outputs = {}
    for kind, info in receipt["files"].items():
        data = bytearray()
        for offset in range(0, info["size"], 6000):
            code = ("import base64,pathlib; p=pathlib.Path(" + repr(info["path"]) + ");"
                    + f"print(base64.b64encode(p.read_bytes()[{offset}:{offset+6000}]).decode())")
            data.extend(base64.b64decode(ssm(label + "-read-" + kind, admin(code)).strip()))
        raw = gzip.decompress(data)
        assert len(raw) == info["raw_size"]
        (directory / ("stdout.log" if kind == "out" else "stderr.log")).write_bytes(raw)
        outputs[kind] = raw.decode(errors="replace")
    return receipt["returncode"], outputs["out"], outputs["err"]

def deliver(path, target):
    assert target in ("/local/nvidia-oci-spec.json", "/local/symphony14-native-spec.json")
    data = Path(path).read_bytes()
    remote = "/.bottlerocket/rootfs" + target
    for offset in range(0, len(data), 4500):
        part = base64.b64encode(data[offset:offset+4500]).decode()
        code = ("import base64,pathlib;p=pathlib.Path(" + repr(remote) + ");"
                + "p.open(" + repr("wb" if offset == 0 else "ab") + ").write(base64.b64decode(" + repr(part) + "))")
        ssm("deliver-spec", admin(code))
    code = "import hashlib,pathlib;print(hashlib.sha256(pathlib.Path(" + repr(remote) + ").read_bytes()).hexdigest())"
    import hashlib
    assert ssm("verify-spec", admin(code)).strip() == hashlib.sha256(data).hexdigest()
    (OUT / "delivered-spec.json").write_bytes(data)

if __name__ == "__main__":
    mode, instance, region = sys.argv[1:4]
    assert instance == INSTANCE and region == REGION
    if mode == "host":
        rc, stdout, stderr = host("smoke-host", shlex.split(sys.argv[4]), int(sys.argv[5]) if len(sys.argv)>5 else 600)
        sys.stdout.write(stdout)
        sys.stderr.write(stderr)
        sys.exit(rc)
    elif mode == "deliver":
        deliver(sys.argv[4], sys.argv[5])
    else:
        raise ValueError(mode)

"""Verify an already registered issue14 AMI without registering it again."""
import datetime
import json
from pathlib import Path
import subprocess
import sys
OUT = Path(sys.argv[1]).resolve()
BASE = Path(__file__).resolve().parent
assert OUT.parent == BASE / "images"
inputs = json.loads((OUT / "inputs.json").read_text())
JOB, source, variant, arch = (inputs[k] for k in ["job", "source", "variant", "arch"])
assert json.loads((OUT / "registration-result.json").read_text())["exit_code"] == 0
def save(name, data):
    (OUT / (name + ".json")).write_text(json.dumps(data, indent=2) + "\n")
def aws(label, *args):
    result = subprocess.run(["aws", *args, "--region", "us-west-2", "--output", "json"], capture_output=True, text=True, timeout=60)
    (OUT / (label + ".stdout")).write_text(result.stdout)
    (OUT / (label + ".stderr")).write_text(result.stderr)
    assert result.returncode == 0, (label, result.stderr)
    return json.loads(result.stdout or "{}")
identity = aws("verification-identity", "sts", "get-caller-identity")
assert identity["Account"] == "533267423195"
ami = json.loads((OUT / "ami.json").read_text())["us-west-2"]["id"]
image = aws("describe-image", "ec2", "describe-images", "--image-ids", ami)["Images"][0]
assert image["State"] == "available" and not image["Public"] and image["OwnerId"] == identity["Account"]
assert image["Architecture"] == ("arm64" if arch == "aarch64" else "x86_64")
assert image["Name"] == json.loads((OUT / "registration-started.json").read_text())["name"]
if variant == "aws-k8s-1.34":
    assert image["BootMode"] == "uefi-preferred" and image.get("TpmSupport") is None
else:
    assert image["BootMode"] == "uefi" and image["TpmSupport"] == "v2.0"
snapshots = [entry["Ebs"]["SnapshotId"] for entry in image["BlockDeviceMappings"] if "Ebs" in entry]
assert len(snapshots) == 2
aws("tags", "ec2", "create-tags", "--resources", ami, *snapshots, "--tags",
    "Key=SymphonyIssue,Value=14", "Key=SymphonyBuild,Value=" + JOB, "Key=SymphonySource,Value=" + source, "Key=SymphonyInput,Value=" + inputs["input_sha256"])
permissions = aws("permissions", "ec2", "describe-image-attribute", "--image-id", ami, "--attribute", "launchPermission")
assert not permissions["LaunchPermissions"]
for snapshot in snapshots:
    permissions = aws("permissions-" + snapshot, "ec2", "describe-snapshot-attribute",
                      "--snapshot-id", snapshot, "--attribute", "createVolumePermission")
    assert not permissions["CreateVolumePermissions"]
observed = aws("snapshots", "ec2", "describe-snapshots", "--snapshot-ids", *snapshots)
assert all(s["State"] == "completed" and s["OwnerId"] == identity["Account"] for s in observed["Snapshots"])
save("verification", {"status": "passed", "ami": ami, "snapshot_ids": snapshots, "job": JOB,
                      "arch": arch, "variant": variant, "source": source, "input_sha256": inputs["input_sha256"], "region": "us-west-2",
                      "private": True, "boot_mode": image["BootMode"], "tpm": image.get("TpmSupport"), "runtime": "pending"})
print(ami, variant, arch, flush=True)

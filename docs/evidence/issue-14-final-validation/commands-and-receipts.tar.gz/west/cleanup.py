"""Remove only EC2 resources recorded by this issue's completed test cases."""
import datetime
import json
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
OUT = BASE / "cleanup"
OUT.mkdir(exist_ok=True)


def aws(label, *args):
    argv = ["aws", *args, "--region", "us-west-2", "--output", "json"]
    result = subprocess.run(argv,
                            capture_output=True, text=True, timeout=60)
    (OUT / (label + ".command.json")).write_text(json.dumps({
        "argv": argv, "exit_code": result.returncode,
        "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    }, indent=2) + "\n")
    (OUT / (label + ".stdout")).write_text(result.stdout)
    (OUT / (label + ".stderr")).write_text(result.stderr)
    assert result.returncode == 0, (label, result.stderr)
    return json.loads(result.stdout or "{}")


def issue14(resource):
    assert {x["Key"]: x["Value"] for x in resource.get("Tags", [])}.get("SymphonyIssue") == "14"


identity = aws("identity", "sts", "get-caller-identity")
assert identity["Account"] == "533267423195"
cases = list((BASE / "cases").glob("*/identity.json"))
assert cases, "No recorded instances"
for path in cases:
    assert path.with_name("result.json").exists(), "Case still running: " + str(path)
commands = []
for path in cases:
    instance_id = json.loads(path.read_text())["instance"]
    for invocation_path in path.parent.rglob("invocation.json"):
        prior = json.loads(invocation_path.read_text())
        if prior["Status"] in ("Success", "Failed", "Cancelled", "TimedOut"):
            continue
        assert prior["InstanceId"] == instance_id
        command_id = prior["CommandId"]
        current = aws("command-before-" + command_id, "ssm", "get-command-invocation",
                      "--command-id", command_id, "--instance-id", instance_id)
        if current["Status"] not in ("Success", "Failed", "Cancelled", "TimedOut"):
            aws("cancel-" + command_id, "ssm", "cancel-command", "--command-id", command_id,
                "--instance-ids", instance_id)
            current = aws("command-after-" + command_id, "ssm", "get-command-invocation",
                          "--command-id", command_id, "--instance-id", instance_id)
        commands.append({"command_id": command_id, "instance": instance_id,
                         "observed_status": current["Status"], "response_code": current["ResponseCode"]})
(OUT / "command-reconciliation.json").write_text(json.dumps(commands, indent=2) + "\n")
instances = sorted({json.loads(p.read_text())["instance"] for p in cases})
response = aws("instances-before", "ec2", "describe-instances", "--instance-ids", *instances)
observed = [i for r in response["Reservations"] for i in r["Instances"]]
assert {i["InstanceId"] for i in observed} == set(instances)
volumes = []
for instance in observed:
    issue14(instance)
    volumes.extend(x["Ebs"]["VolumeId"] for x in instance.get("BlockDeviceMappings", []) if "Ebs" in x)
aws("terminate", "ec2", "terminate-instances", "--instance-ids", *instances)
deadline = time.monotonic() + 600
while True:
    response = aws("instances-after", "ec2", "describe-instances", "--instance-ids", *instances)
    if all(i["State"]["Name"] == "terminated" for r in response["Reservations"] for i in r["Instances"]):
        break
    assert time.monotonic() < deadline, "Instance termination not complete"
    time.sleep(15)
remaining = aws("remaining-volumes", "ec2", "describe-volumes", "--filters", "Name=tag:SymphonyIssue,Values=14")
deadline = time.monotonic() + 180
while any(v["State"] != "available" for v in remaining["Volumes"]):
    assert all(v["VolumeId"] in volumes for v in remaining["Volumes"])
    assert time.monotonic() < deadline, "Test volumes have not finished detaching or deleting"
    time.sleep(5)
    remaining = aws("remaining-volumes", "ec2", "describe-volumes", "--filters", "Name=tag:SymphonyIssue,Values=14")
for volume in remaining["Volumes"]:
    issue14(volume)
    assert volume["VolumeId"] in volumes and volume["State"] == "available" and not volume["Attachments"]
    aws("delete-" + volume["VolumeId"], "ec2", "delete-volume", "--volume-id", volume["VolumeId"])
images = []
snapshots = []
for path in (BASE / "images").glob("*/verification.json"):
    receipt = json.loads(path.read_text())
    image = aws("image-" + receipt["ami"], "ec2", "describe-images", "--image-ids", receipt["ami"])["Images"][0]
    issue14(image)
    assert image["OwnerId"] == identity["Account"] and not image["Public"]
    assert {x["Key"]: x["Value"] for x in image["Tags"]}["SymphonyBuild"] == receipt["job"]
    ids = [x["Ebs"]["SnapshotId"] for x in image["BlockDeviceMappings"] if "Ebs" in x]
    assert set(ids) == set(receipt["snapshot_ids"])
    snapshot_rows = aws("snapshots-" + receipt["ami"], "ec2", "describe-snapshots", "--snapshot-ids", *ids)["Snapshots"]
    for snapshot in snapshot_rows:
        issue14(snapshot)
        assert snapshot["OwnerId"] == identity["Account"]
    aws("deregister-" + receipt["ami"], "ec2", "deregister-image", "--image-id", receipt["ami"])
    for snapshot in ids:
        aws("delete-" + snapshot, "ec2", "delete-snapshot", "--snapshot-id", snapshot)
    images.append(receipt["ami"])
    snapshots.extend(ids)
stack = json.loads((BASE / "stack-observed.json").read_text())["Stacks"][0]
current = aws("stack-before", "cloudformation", "describe-stacks", "--stack-name", stack["StackId"])["Stacks"][0]
issue14(current)
assert current["StackId"] == stack["StackId"]
aws("delete-stack", "cloudformation", "delete-stack", "--stack-name", stack["StackId"])
deadline = time.monotonic() + 600
while True:
    current = aws("stack-after", "cloudformation", "describe-stacks", "--stack-name", stack["StackId"])["Stacks"][0]
    if current["StackStatus"] == "DELETE_COMPLETE":
        break
    assert current["StackStatus"] != "DELETE_FAILED" and time.monotonic() < deadline, current["StackStatus"]
    time.sleep(15)
left = aws("final-images", "ec2", "describe-images", "--owners", "self", "--filters", "Name=tag:SymphonyIssue,Values=14")["Images"]
assert not left
left = aws("final-snapshots", "ec2", "describe-snapshots", "--owner-ids", "self", "--filters", "Name=tag:SymphonyIssue,Values=14")["Snapshots"]
assert not left
left = aws("final-volumes", "ec2", "describe-volumes", "--filters", "Name=tag:SymphonyIssue,Values=14")["Volumes"]
assert not left
(OUT / "result.json").write_text(json.dumps({
    "status": "passed", "at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "terminated_instances": instances, "deregistered_images": images, "deleted_snapshots": snapshots,
    "deleted_stack": stack["StackId"], "existing_default_vpc_and_subnet": "retained",
}, indent=2) + "\n")

"""Summarize recorded results without treating incomplete cases as passing."""
import datetime
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[5]
rows = []
for case in json.loads((BASE / 'image-jobs.json').read_text()):
    row = dict(case)
    directory = ROOT / '.symphony/builds' / case['job']
    for name in ['result.json', 'cloud-result.json']:
        if (directory / name).exists():
            result = json.loads((directory / name).read_text())
            row['build_status'] = result['status']
            row['build_result_path'] = str(directory / name)
            break
    row.setdefault('build_status', 'pending')
    registered = BASE / 'images' / case['job'] / 'verification.json'
    if registered.exists():
        row['image'] = json.loads(registered.read_text())
    path = BASE / 'cases' / (case['variant'] + '-' + case['arch'])
    if (path / 'identity.json').exists():
        row['instance'] = json.loads((path / 'identity.json').read_text())['instance']
    if (path / 'result.json').exists():
        row['runtime'] = json.loads((path / 'result.json').read_text())
    else:
        row['runtime'] = {'status': 'pending'}
    for label in ['policy-before', 'policy-after']:
        p = path / (label + '.json')
        if p.exists():
            policy = json.loads(p.read_text())
            row[label] = {'status': policy['status'], 'checks': len(policy['checks']),
                          'errors': policy['errors'], 'mount_unit': policy.get('mount_unit')}
    ids = []
    for p in (path / 'commands').glob('*/invocation.json'):
        invocation = json.loads(p.read_text())
        ids.append({'id': invocation['CommandId'], 'status': invocation['Status'],
                    'response_code': invocation['ResponseCode'], 'path': str(p.relative_to(BASE))})
    row['ssm_commands'] = ids
    rows.append(row)
cleanup_path = BASE / 'cleanup/result.json'
cleanup = json.loads(cleanup_path.read_text()) if cleanup_path.exists() else {'status': 'pending'}
summary = {'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'release': json.loads((BASE / 'release-config.json').read_text()),
           'status': 'passed' if len(rows) == 5 and all(r['runtime']['status'] == 'passed' for r in rows) else 'incomplete',
           'cases': rows, 'cleanup': cleanup, 'registry_cleanup': 'pending conductor receipt'}
(BASE / 'validation-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
for row in rows:
    print(row['variant'], row['arch'], row['build_status'], row['runtime']['status'], row.get('instance', '-'))

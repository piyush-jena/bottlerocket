# All five cases passed, 2026-10-06T22:57:35.654901+00:00

All five fresh image builds and runtime cases passed. Each case passed 38 policy assertions before and 38 after container execution. The two supplied GPU workflows exited 0, reported one NVIDIA L4, deviceQuery PASS and vectorAdd PASSED.

The successful GPU instance type is g6.2xlarge in us-east-2c after g6.xlarge capacity failures in three zones. No failed attempt created an instance, as verified by client tokens. See capacity-recovery for each attempt.

- aws-mantle-1 x86_64: ami-019bb8caaf77b3463, i-02393698098b1c108; 47 successful SSM invocations.
- aws-mantle-1 aarch64: ami-0df3f6053844bc807, i-0ab72aa43e1cee521; 45 successful SSM invocations.
- aws-mantle-1-fips x86_64: ami-00f2b4235b558b774, i-04b39cc386d65f0d9; 47 successful SSM invocations.
- aws-mantle-1-nvidia x86_64: ami-0c7235b305234a123, i-063fae68a34d43e3a; 63 successful SSM invocations.
- aws-mantle-1-nvidia-fips x86_64: ami-00a1be9870b34c930, i-0788bbca00e537a35; 63 successful SSM invocations.

EC2 cleanup is running; registry cleanup and PR publication remain outstanding. No reboot or non-UKI control pass is claimed for this revision.

# UKI drop-in live validation milestone

As of 2026-10-06T22:47:50.462184+00:00, the three non-GPU cases pass.

| Variant | Architecture | AMI | Instance | Boot, policy and native container |
| --- | --- | --- | --- | --- |
| aws-mantle-1 | x86_64 | ami-019bb8caaf77b3463 | i-02393698098b1c108 | pass |
| aws-mantle-1 | aarch64 | ami-0df3f6053844bc807 | i-0ab72aa43e1cee521 | pass |
| aws-mantle-1-fips | x86_64 | ami-00f2b4235b558b774 | i-04b39cc386d65f0d9 | pass |

Each case passed 38 policy checks before and 38 after native-container execution.
The effective blacklist includes i8042 and binfmt_misc. The module, filesystem
and mount remain absent; named modprobe, filesystem-alias modprobe and insmod
are rejected. The packaged mount is loaded/inactive with ConditionResult=no
and Result=success after an explicit start. No boot units are failed.

The source is Bottlerocket 3f1f18e74640c671872a6b114bd42dddb612ea68 plus the
recorded temporary configuration patch. Release is numeric 1.66.1, BUILD_ID
3f1f18e7-dirty. Core-kit is 17.0.1-symphony.14.build-fa6d388f; Twoliter is
d2c650ad1489fe545f68c4fcbd481f2163ed5629. Source snapshots, artifact hashes,
private image/snapshot verification and SSM command records are retained in
source-verification.json, images/, cases/, and validation-summary.json.

The required make integ gate passed with exit 0 in this turn. Its full output
is in make-integ.log. This milestone does not claim GPU validation, reboot
coverage or completed cleanup. Both GPU image builds and their EC2 tests
remain outstanding. The three instances, AMIs/snapshots, access stack and
owned kit registry remain available until the matrix is complete; clean up
these recorded resources afterward. Temporary product configuration is still
present and must not change while image builds run.

Registration can consume a successful cloud-result.json plus observer exit 0
before the conductor delivers result.json. It records the exact result source,
verifies immutable inputs, matches the output receipt's input digest and hashes
every compressed and uncompressed image. No harness reconciliation helper,
product build execution, Gitea write, or product source change was performed in this turn.

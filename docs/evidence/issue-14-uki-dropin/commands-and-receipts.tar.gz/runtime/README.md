# Issue 14 UKI drop-in image validation inputs, 2026-10-06

Both core-kit builds and offline RPM inspections passed. Their archives were
published as `17.0.1-symphony.14.build-fa6d388f`; `kit-publication.json` and
`registry-readback.json` preserve the verified two-architecture receipt.

The Bottlerocket product revision is `3f1f18e74640c671872a6b114bd42dddb612ea68`.
Only Release.toml, Twoliter.toml and Twoliter.lock contain temporary uncommitted
test inputs. The issue explicitly requests numeric OS release 1.66.1 and
AMI names containing symphony.14.r10, matching the earlier approved test round.
The empty (1.66.0, 1.66.1) migration entry is present. These input changes are
not intended for the product PR. `original-config` preserves the originals;
`tested-config`, `test-configuration.patch` and `release-config.json` record
all changed bytes, hashes and the expected BUILD_ID `3f1f18e7-dirty`.

Twoliter `d2c650ad1489fe545f68c4fcbd481f2163ed5629` is the already validated
revision. Its tree equals the current issue branch's aa8a122 revision. No
Twoliter source or checkout change was made. SDK and kernel-kit lock entries
remain byte-equivalent as TOML values to the original lock. Both Release.toml
and Twoliter.toml declare the same numeric release. All four mantle manifests
have exactly one module_blacklist=i8042,binfmt_misc and no systemd.mask= entry.
Twoliter update and git diff --check passed. The existing Symphony make integ
result covers unchanged implementation sources; no new harness gate was run.

`superseded-images.json` records the earlier five successful build receipts
and their artifact hashes. They used the generator policy and cannot validate
the UKI drop-in. The old AMIs and runtime resources were cleaned up.

Next steps after five queued image builds:

1. Inspect each returned source snapshot, configuration hashes, artifact hashes,
   UKI cmdline and packaged drop-in. Retain the exact input archive digest.
2. Register private AMIs in us-east-2 with symphony.14.r10 names and build IDs.
3. Reuse the reviewed runtime recipe from bottlerocket/.symphony/runtime-r10,
   but copy it here and adapt its relative root paths. The old register_image.py
   requires a clean tree: replace that assumption with verification of the
   recorded source, exact three-file patch and configuration hashes. Do not
   bypass source validation. Compare the immutable input snapshot to these
   records before registration. The expected BUILD_ID includes -dirty.
4. Use core-kit/docs/evidence/issue-14-uki-dropin/policy.py for the revised
   live assertions. Run before and after native containers or the supplied
   NVIDIA smoke recipe, on base x86_64/aarch64 and FIPS/NVIDIA/NVIDIA-FIPS x86_64.
   Record SSM command IDs, full output, image digests and resource cleanup.
5. Restore the three temporary configs only after all image captures/builds
   finish. Preserve this evidence for the final PR reports. No new final
   adversarial review is needed: it already ran before this human review change.

This turn did not register AMIs, launch instances or claim live validation.
No source may change while its queued image builds are running.

## Runtime preparation, turn 6

The copied runtime scripts now live here. `verify_inputs.py` passed against all
five immutable input archives, checking exact recorded file hashes and dependency
identity. Registration invokes that verification and ties the successful output
receipt to the captured input digest. The old clean-tree assumption is replaced
by verification of the three specific temporary configuration files.

The launch runner waits for admin readiness after SSM comes online and checks
for conflicting container/rootfs names before running the supplied recipe.
GPU main and CDI merge hashes match the supplied workflow; the SSM transport
continues to retain command IDs and retrieve complete compressed output.
All Python scripts parse, and the shell recipes pass bash -n.

The host AWS account and existing default network were verified. A new
`symphony-14-uki-dropin` access stack uses the previously tested runtime role
and outbound-only security group. `runtime-readiness.json` records its exact
identity and latest state. Keep and later clean up this stack. No AMI or test
instance has been created yet. Do not invoke the older run_all.py: its harness
reconciliation helper is not part of this turn's permitted runtime work.

"""Export completed runtime evidence, excluding disk images and publisher binaries."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

BASE = Path(__file__).resolve().parent
MEMBER = BASE.parents[2]
STAGE = MEMBER.parent
DEST = MEMBER / "docs/evidence/issue-14-uki-dropin"
summary = json.loads((BASE / "validation-summary.json").read_text())
assert summary["status"] == "passed"
cleanup = json.loads((BASE / "cleanup/result.json").read_text())
assert cleanup["status"] == "passed"
DEST.mkdir(parents=True, exist_ok=True)
files = {}
for path in BASE.rglob("*"):
    if not path.is_file() or path.is_symlink():
        continue
    rel = path.relative_to(BASE)
    if rel.parts[0] in {"tools", "__pycache__"} or "__pycache__" in rel.parts:
        continue
    if path.suffix in {".img", ".lz4", ".pyc", ".tar", ".gz"}:
        continue
    assert path.stat().st_size < 50_000_000, str(path)
    files["runtime/" + str(rel)] = path
for job in ["43e02580-38ce-8015-af43-98dfc1e8e1f7", "e75c116b-d698-8c08-af5c-d1c584b223e8"]:
    inspection = STAGE / "kits/bottlerocket-core-kit/build/symphony" / job / "inspection"
    for path in inspection.iterdir():
        if path.suffix != ".rpm" and path.is_file():
            files[f"kit-inspection/{job}/{path.name}"] = path
jobs = [row["job"] for row in summary["cases"]]
jobs += ["43e02580-38ce-8015-af43-98dfc1e8e1f7", "e75c116b-d698-8c08-af5c-d1c584b223e8",
         "fba33ee6-f05c-4a89-958b-4264f17a54fd"]
for job in jobs:
    directory = STAGE.parents[1] / ".symphony/builds" / job
    for name in ["build.log", "cloud-result.json", "remote-result.json", "collection-receipt.json", "observer-exit.code"]:
        path = directory / name
        if path.is_file():
            files[f"builds/{job}/{name}"] = path
manifest = {name: {"sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                   "size": path.stat().st_size}
            for name, path in sorted(files.items())}
with tarfile.open(DEST / "commands-and-receipts.tar.gz", "w:gz") as archive:
    for name, path in sorted(files.items()):
        archive.add(path, arcname=name, recursive=False)
(DEST / "bundle-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
for name in ["validation-summary.json", "release-config.json", "test-configuration.patch",
             "kit-publication.json", "image-pins.json", "gate-result.json", "workflow-source.json",
             "tool-verification.json"]:
    shutil.copy2(BASE / name, DEST / name)
shutil.copy2(BASE / "cleanup/result.json", DEST / "ec2-cleanup.json")
for row in summary["cases"]:
    case = row["variant"] + "-" + row["arch"]
    dest = DEST / "cases" / case
    dest.mkdir(parents=True, exist_ok=True)
    for name in ["result.json", "policy-before.json", "policy-after.json",
                 "native-smoke.stdout", "nvidia-smoke.stdout", "nvidia-smoke.stderr"]:
        path = BASE / "cases" / case / name
        if path.exists():
            shutil.copy2(path, dest / name)
    for name in ["inputs.json", "verification.json"]:
        shutil.copy2(BASE / "images" / row["job"] / name, dest / name)
print(json.dumps({"files": len(files), "archive_sha256": hashlib.sha256(
    (DEST / "commands-and-receipts.tar.gz").read_bytes()).hexdigest()}, indent=2))

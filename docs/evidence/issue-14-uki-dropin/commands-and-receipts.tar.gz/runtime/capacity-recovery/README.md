EC2 returned InsufficientInstanceCapacity for g6.xlarge in us-east-2a. The client-token query found no instance. Retry uses existing default subnet subnet-052bf17f987697fcb in us-east-2b, the same VPC, AMI, instance type, role and security group. No image or product source changed. The failed attempt is retained here.

Both GPU launches returned InsufficientInstanceCapacity in us-east-2b; client-token checks found no instances. Retrying both unchanged AMIs in the existing default us-east-2c subnet subnet-0ed7870ed2575c551.

Both g6.xlarge launches also failed for capacity in us-east-2c, with no instances found by client token. Retry uses g6.2xlarge in us-east-2c. DescribeInstanceTypes confirms one NVIDIA L4 GPU, UEFI and NitroTPM support. Client tokens include the new instance type; all previous failed attempts remain recorded. No product source changed.

"""Export a partial, explicitly blocked validation checkpoint without binary artifacts."""
import datetime,hashlib,json,shutil,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
MEMBER=BASE.parents[2]
DEST=MEMBER/'docs/evidence/issue-14-systemd-guard'
DEST.mkdir(parents=True,exist_ok=True)
rows=[]
for directory in sorted((BASE/'images').iterdir()):
 verified=json.loads((directory/'verification.json').read_text())
 inputs=json.loads((directory/'inputs.json').read_text())
 case=BASE/'cases'/(verified['variant']+'-'+verified['arch'])
 result=json.loads((case/'result.json').read_text()) if (case/'result.json').exists() else {'status':'blocked','reason':'GPU launch refused; retained attempts in capacity-recovery'}
 commands=[]
 for p in case.rglob('invocation.json'):
  invocation=json.loads(p.read_text());commands.append({'command_id':invocation['CommandId'],'status':invocation['Status'],'response_code':invocation['ResponseCode'],'path':str(p.relative_to(BASE))})
 row={'image':verified,'artifacts':inputs['images'],'uefi_sha256':inputs['uefi_sha256'],'publisher_sha256':inputs['publisher_sha256'],'runtime':result,'ssm_commands':commands}
 if (case/'followup/result.json').exists():row['followup']=json.loads((case/'followup/result.json').read_text())
 rows.append(row)
cleanup=json.loads((BASE/'partial-cleanup/result.json').read_text())
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'blocked','release':json.loads((BASE/'release-config.json').read_text()),'cases':rows,'capacity':json.loads((BASE/'capacity-blocker.json').read_text()),'partial_cleanup':cleanup,'limitations':'Both GPU runtime cases remain untested. This checkpoint is not final acceptance; AMIs, snapshots, access stack and registry are retained to resume.'}
(BASE/'validation-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
for p in BASE.rglob('*'):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(BASE)
 if 'tools' in rel.parts or '__pycache__' in rel.parts:continue
 if p.suffix in {'.img','.lz4','.pyc','.tar','.gz','.pem'}:continue
 if p.name.startswith('lock-update-debug.'):continue
 assert p.stat().st_size<50000000,p
 files['runtime/'+str(rel)]=p
build_root=MEMBER.parent.parents[1]/'.symphony/builds'
for row in rows:
 job=row['image']['job'];directory=build_root/job
 for name in ['build.log','cloud-result.json','remote-result.json','collection-receipt.json','observer-exit.code','artifacts/source-provenance.json','artifacts/twoliter-provenance.txt']:
  p=directory/name
  if p.is_file():files['builds/'+job+'/'+name]=p
manifest={name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size} for name,p in sorted(files.items())}
with tarfile.open(DEST/'commands-and-receipts.tar.gz','w:gz') as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
(DEST/'bundle-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for n in ['validation-summary.json','capacity-blocker.json','release-config.json','registry-result.json','image-pins.json','workflow-source.json','configuration-restored.json','base_followup.py','setup_access.py','stop_completed.py','policy.py','tool-verification.json']:
 shutil.copy2(BASE/n,DEST/n)
for row in rows:
 case=row['image']['variant']+'-'+row['image']['arch'];dest=DEST/'cases'/case;dest.mkdir(parents=True,exist_ok=True)
 for n in ['policy-before.json','policy-after.json','result.json','native-smoke.stdout']:
  p=BASE/'cases'/case/n
  if p.exists():shutil.copy2(p,dest/n)
 followup=BASE/'cases'/case/'followup'
 if followup.exists():
  (dest/'followup').mkdir(exist_ok=True)
  for n in ['policy-after-direct-mount.json','policy-after-reboot.json','direct-mount.json','result.json']:
   shutil.copy2(followup/n,dest/'followup'/n)
receipt={'status':'blocked-checkpoint','files':len(files),'archive_sha256':hashlib.sha256((DEST/'commands-and-receipts.tar.gz').read_bytes()).hexdigest()}
(DEST/'bundle-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt),flush=True)

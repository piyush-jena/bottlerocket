"""Verify recorded release inputs against the immutable image build snapshot."""
import hashlib
import json
from pathlib import Path
import tarfile
import tomllib

BASE = Path(__file__).resolve().parent
MEMBER = BASE.parents[2]
ROOT = BASE.parents[5]


def verify_inputs(job):
    config = json.loads((BASE / "release-config.json").read_text())
    directory = ROOT / ".symphony/builds" / job
    cloud = json.loads((directory / "cloud.json").read_text())
    plan = cloud["plan"]
    source = plan["sources"]["member"]
    assert cloud["issue"] == 14 and cloud["member"] == str(MEMBER)
    assert source["revision"] == config["source"]
    assert source["tracked_changes"] == config["tracked_changes"]
    assert plan["sources"]["twoliter"] == {
        "revision": config["twoliter_revision"], "tracked_changes": ""
    }
    assert plan["dependencies"] == [{
        "kit": "bottlerocket-core-kit",
        "vendor": "local",
        "version": config["kit"],
        "index_digest": config["core_index_digest"],
    }]
    variant = plan["request"]["variant"]
    assert variant in {
        "aws-mantle-1", "aws-mantle-1-fips",
        "aws-mantle-1-nvidia", "aws-mantle-1-nvidia-fips",
    }
    checked = {}
    with tarfile.open(directory / "input.tar") as archive:
        def read(name):
            stream = archive.extractfile("./" + name)
            assert stream is not None
            return stream.read()

        for name, expected in config["configuration_sha256"].items():
            data = read("member/" + name)
            observed = hashlib.sha256(data).hexdigest()
            assert observed == expected, (name, observed, expected)
            checked[name] = observed
        name = f"variants/{variant}/Cargo.toml"
        manifest = read("member/" + name)
        assert manifest == (MEMBER / name).read_bytes()
        checked[name] = hashlib.sha256(manifest).hexdigest()
        parameters = tomllib.loads(manifest.decode())["package"]["metadata"]["build-variant"]["kernel-parameters"]
        assert [p for p in parameters if p.startswith("module_blacklist=")] == [
            "module_blacklist=i8042,binfmt_misc"
        ]
        assert not any(p.startswith("systemd.mask=") for p in parameters)
        receipt = json.loads(read("dependencies/bottlerocket-core-kit/receipt.json"))
        assert receipt["version"] == config["kit"]
        assert receipt["index_digest"] == config["core_index_digest"]
        assert set(receipt["platforms"]) == {"aarch64", "x86_64"}

    return {
        "status": "passed", "job": job, "source": source,
        "input_sha256": cloud["input_sha256"],
        "configuration_patch_sha256": config["configuration_patch_sha256"],
        "checked_snapshot_files": checked,
        "core_version": config["kit"], "core_index_digest": config["core_index_digest"],
        "twoliter_revision": config["twoliter_revision"],
        "variant": variant, "arch": plan["request"]["arch"],
    }


if __name__ == "__main__":
    import sys
    print(json.dumps(verify_inputs(sys.argv[1]), indent=2))

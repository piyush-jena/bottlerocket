"""Register only verified, successful issue-14 image outputs; retain all receipts."""
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

BASE = Path(__file__).resolve().parent
MEMBER = BASE.parents[2]
ROOT = BASE.parents[5]
JOB = sys.argv[1]
BUILD = ROOT / ".symphony/builds" / JOB
OUT = BASE / "images" / JOB
OUT.mkdir(parents=True, exist_ok=True)
assert not (OUT / "registration-started.json").exists(), "Reconcile prior registration first"


def save(name, data):
    (OUT / (name + ".json")).write_text(json.dumps(data, indent=2) + "\n")


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def aws(label, *args):
    result = subprocess.run(["aws", *args, "--region", "us-east-2", "--output", "json"],
                            capture_output=True, text=True, timeout=60)
    (OUT / (label + ".stdout")).write_text(result.stdout)
    (OUT / (label + ".stderr")).write_text(result.stderr)
    assert result.returncode == 0, (label, result.stderr)
    return json.loads(result.stdout or "{}")


identity = aws("identity", "sts", "get-caller-identity")
assert identity["Account"] == "533267423195"
result_path = BUILD / "result.json"
if not result_path.exists():
    result_path = BUILD / "cloud-result.json"
    assert (BUILD / "observer-exit.code").read_text().strip() == "0"
result = json.loads(result_path.read_text())
assert result["status"] == "succeeded" and result["exit_code"] == 0, result
assert result["request_id"] == JOB
save("build-result", {"path": str(result_path), "result": result})
cloud = json.loads((BUILD / "cloud.json").read_text())
assert cloud["issue"] == 14 and cloud["member"] == str(MEMBER)
plan = cloud["plan"]
from verify_inputs import verify_inputs
attestation = verify_inputs(JOB)
save("source-attestation", attestation)
variant, arch = plan["request"]["variant"], plan["request"]["arch"]
source = plan["sources"]["member"]["revision"]
name = f"symphony.14.r10-bottlerocket-{variant}-{arch}-v1.66.1-{source[:8]}-{JOB[:8]}"
existing = aws("existing", "ec2", "describe-images", "--owners", "self", "--filters", "Name=name,Values=" + name)
assert not existing["Images"], "Reconcile existing image before registering"
remote = json.loads((BUILD / "remote-result.json").read_text())
assert remote["exit_code"] == 0 and remote["input_sha256"] == attestation["input_sha256"]
images = []
for entry in remote["files"]:
    if not entry["path"].endswith(".img.lz4"):
        continue
    archive = MEMBER / "build/symphony" / JOB / Path(entry["path"]).relative_to("member/build")
    assert digest(archive) == entry["sha256"]
    image = OUT / archive.name.removesuffix(".lz4")
    subprocess.run(["lz4", "-d", "-f", str(archive), str(image)], check=True, capture_output=True)
    images.append({"archive": str(archive), "archive_sha256": entry["sha256"],
                   "image": str(image), "sha256": digest(image), "size": image.stat().st_size})
assert len(images) == 2, images
uefi = BUILD / "artifacts/state/sbkeys/local/efi-vars.aws"
expected = next(x["sha256"] for x in remote["files"] if x["path"] == "state/sbkeys/local/efi-vars.aws")
assert digest(uefi) == expected
tool_identity = json.loads((BASE / "publisher-identity.json").read_text())
publisher = BASE / "tools/pubsys"
if not publisher.exists():
    shutil.copy2(tool_identity["path"], publisher)
assert digest(publisher) == tool_identity["sha256"]
(OUT / "Infra.toml").write_text('[aws]\nregions = ["us-east-2"]\n')
os_image = next(x["image"] for x in images if not x["image"].endswith("-data.img"))
data_image = next(x["image"] for x in images if x["image"].endswith("-data.img"))
argv = [
    str(publisher), "--infra-config-path", str(OUT / "Infra.toml"), "ami",
    "--os-image", os_image, "--data-image", data_image,
    "--variant-manifest", str(MEMBER / "variants" / variant / "Cargo.toml"),
    "--uefi-data", str(uefi), "--arch", arch, "--name", name,
    "--description", f"Private Symphony issue 14 binfmt EC2 validation; source {source}; build {JOB}",
    "--regions", "us-east-2", "--ami-output", str(OUT / "ami.json"), "--no-progress",
]
save("inputs", {"job": JOB, "input_sha256": attestation["input_sha256"], "source": source, "variant": variant, "arch": arch, "images": images,
                "uefi_sha256": expected, "publisher_sha256": digest(publisher), "argv": argv})
save("registration-started", {"at": datetime.datetime.now(datetime.timezone.utc).isoformat(), "name": name})
with (OUT / "registration.log").open("w") as log:
    registered = subprocess.run(argv, stdout=log, stderr=subprocess.STDOUT)
save("registration-result", {"exit_code": registered.returncode})
assert registered.returncode == 0
subprocess.run(["python3", str(BASE / "verify_image.py"), str(OUT)], check=True)
